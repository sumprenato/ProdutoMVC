/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.util.List;
import model.Produto;

/**
 *
 * @author r.silva
 */
public class ProdutoView {

    public void mostrarProduto(Produto produto) {
        System.out.println("Produto:");
        System.out.println("ID: " + produto.getId());
        System.out.println("Nome: " + produto.getNome());
        System.out.println("Preço: R$" + produto.getPreco());
        System.out.println();
    }

    public void listarProdutos(List<Produto> produtos) {
        System.out.println("\nLista de Produtos:");
        for (Produto p : produtos) {
            mostrarProduto(p);
        }
    }

    public void mostrarMensagem(String mensagem) {
        System.out.println(mensagem);
    }
}
