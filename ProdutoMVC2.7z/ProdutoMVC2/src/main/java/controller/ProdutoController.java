/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author r.silva
 */

import model.Produto;
import view.ProdutoView;

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;
import model.Produto;
import view.ProdutoView;

public class ProdutoController {
    private List<Produto> produtos;
    private ProdutoView view;
    private int proximoId = 1;

    public ProdutoController(ProdutoView view) {
        this.produtos = new ArrayList<>();
        this.view = view;
    }

    public void adicionarProduto(String nome, double preco) {
        Produto novoProduto = new Produto(proximoId++, nome, preco);
        produtos.add(novoProduto);
        view.mostrarMensagem("Produto adicionado com sucesso!");
    }

    public void listarProdutos() {
        view.listarProdutos(produtos);
    }
}
